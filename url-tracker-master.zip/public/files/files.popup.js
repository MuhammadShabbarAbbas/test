// https://gerardbalaoro.github.io/jquery.filer/#documentation
var fileuploader = {
    filer : null,
    files : null,
    showThumbs: true,
    removeConfirmation : false,
    fileMaxSize : 100,
    maxSize : 500,
    init : function(){
        this.bindEvents();
        // filesStorage.set(null, () => {
        //     // filesStorage.get(data => {DEBUG ? console.log(data) : ""});
        // });
        filesStorage.get(data => {
            console.log(data);
            if(Array.isArray(data) && data.length >  0 ) this.files = data;
            this.filer = $('#filer_input').filer({
                showThumbs: true,
                addMore: true,
                allowDuplicates: false,
                files:  this.files,
                clipBoardPaste: true,
                changeInput: '<div class="jFiler-input-dragDrop"><div class="jFiler-input-inner"><div class="jFiler-input-icon"><i class="icon-jfi-cloud-up-o"></i></div><div class="jFiler-input-text"><h3>Drag&Drop files here</h3> <span style="display:inline-block; margin: 15px 0">or</span></div><a class="jFiler-input-choose-btn blue">Browse Files</a></div></div>',
                theme: "dragdropbox",
                templates: {
                    box: '<ul class="jFiler-items-list jFiler-items-grid"></ul>',
                    item: '<li class="jFiler-item">\
						<div class="jFiler-item-container">\
							<div class="jFiler-item-inner">\
								<div class="jFiler-item-thumb">\
									<div class="jFiler-item-status"></div>\
									<div class="jFiler-item-thumb-overlay">\
										<div class="jFiler-item-info">\
											<div style="display:table-cell;vertical-align: middle;">\
												<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name}}</b></span>\
												<span class="jFiler-item-others">{{fi-size2}}</span>\
											</div>\
										</div>\
									</div>\
									{{fi-image}}\
								</div>\
								<div class="jFiler-item-assets jFiler-row">\
									<ul class="list-inline pull-left">\
										<li>{{fi-progressBar}}</li>\
									</ul>\
									<ul class="list-inline pull-right">\
										<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
									</ul>\
								</div>\
							</div>\
						</div>\
					</li>',
                    itemAppend: '<li class="jFiler-item">\
							<div class="jFiler-item-container">\
								<div class="jFiler-item-inner">\
									<div class="jFiler-item-thumb">\
										<div class="jFiler-item-status"></div>\
										<div class="jFiler-item-thumb-overlay">\
											<div class="jFiler-item-info">\
												<div style="display:table-cell;vertical-align: middle;">\
													<span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name}}</b></span>\
													<span class="jFiler-item-others">{{fi-size2}}</span>\
												</div>\
											</div>\
										</div>\
										{{fi-image}}\
									</div>\
									<div class="jFiler-item-assets jFiler-row">\
										<ul class="list-inline pull-left">\
											<li><span class="jFiler-item-others">{{fi-icon}}</span></li>\
										</ul>\
										<ul class="list-inline pull-right">\
											<li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
										</ul>\
									</div>\
								</div>\
							</div>\
						</li>',
                    progressBar: '<div class="bar"></div>',
                    itemAppendToEnd: false,
                    canvasImage: true,
                    _selectors: {
                        list: '.jFiler-items-list',
                        item: '.jFiler-item',
                        progressBar: '.bar',
                        remove: '.jFiler-item-trash-action'
                    }
                },


                //     [{
                //     name: 'file.txt', // file name
                //     size: 1024, // file size in bytes
                //     type: 'text/plain', // file MIME type
                //     file: 'uploads/file.txt', // file path
                //     local: '../uploads/file.txt', // file path in listInput (optional)
                //     data: {
                //         thumbnail: 'uploads/file_thumbnail.jpg', // item custom thumbnail; if false will disable the thumbnail (optional)
                //         readerCrossOrigin: 'anonymous', // fix image cross-origin issue (optional)
                //         readerForce: true, // prevent the browser cache of the image (optional)
                //         readerSkip: true, // skip file from reading by rendering a thumbnail (optional)
                //         popup: false, // remove the popup for this file (optional)
                //         listProps: {}, // custom key: value attributes in the fileuploader's list (optional)
                //         your_own_attribute: 'your own value'
                //     }
                // }]

                onSelect: (item, listEl, parentEl, newInputEl, inputEl) => {
                    /**
                     * Images will be added automatically in images upload
                     * @type {string[]}
                     */
                        // const validImageTypes = ['image/gif', 'image/jpeg', 'image/png'];
                        // if (!validImageTypes.includes(item['type'])) {
                        //     images.uploader.addImage([item]);
                        //     return;
                        // }
                    if(this.files == null ) this.files= [];
                    this.files.push(this.fileToJson(item));
                    // this.files.push(item);
                    this.refreshStorage();
                    // this.storeFile(item).then((data)=>{
                    //     DEBUG ? console.log(data) : "";
                    // })
                    // console.log(item);
                    // filesStorage.get(data => {
                    //     if (!Array.isArray(data)) {
                    //         data = [];
                    //     }
                    //     data.push(this.fileToJson(item));
                    //     filesStorage.set(data, () => {
                    //         // filesStorage.get(data => {DEBUG ? console.log(data) : ""});
                    //     });
                    // });
                },
                // onFileCheck : (file) =>{
                //     console.log(file);
                //
                //     // const validImageTypes = ['image/gif', 'image/jpeg', 'image/png','image/bmp'];
                //     // if (validImageTypes.includes(file.type)) return false;
                //
                //     // only return if file is not image
                // },
                // beforeSelect : (filesList) =>{
                //     jQuery.each(filesList,  (i, item) =>{
                //         const validImageTypes = ['image/gif', 'image/jpeg', 'image/png','image/bmp'];
                //         if (validImageTypes.includes(item['type'])) {
                //             images.uploader.addImage([item]);
                //         }
                //     });
                //      return true;
                // },
                onRemove: (item, listEl, parentEl, newInputEl, inputEl) => {
                    if (Array.isArray(this.files)) {
                        let index = this.files.findIndex(x => x.name === this.fileToJson(listEl, false).name);
                        this.files.splice(index, 1);
                        this.refreshStorage();
                    }
                    // filesStorage.get(data => {
                    //
                    //     filesStorage.set(data, () => {
                    //         filesStorage.get(data => {DEBUG ? console.log(data) : ""});
                    //     });
                    // });
                    // return true;
                },
                dragDrop: {
                    dragEnter: null,
                    dragLeave: null,
                    drop: null,
                    dragContainer: null,
                },
            });

            // file_name = filerKit.files_list[id].name;
        });
    },
    refreshStorage : function(){
        filesStorage.set(this.files, () => {
            filesStorage.get(data => {DEBUG ? console.log(data) : ""});
        });
    },
    bindEvents : function(){
        //couldn't implement pasting
        // jQuery(window).on('paste', (this.paste).bind(this));
    },
    // paste: function(ev) {
    //
    //     if (!jQuery('input, textarea').is(ev.target)){
    //
    //         var clipboardData = ev.originalEvent.clipboardData;
    //         if (clipboardData) {
    //             if (clipboardData.files.length == 0) {
    //                 return;
    //             }
    //             jQuery.each(clipboardData.files,  (i, item) =>{
    //                 if(!Array.isArray(this.files)) this.files = [];
    //                 // this.uploader.addImage();
    //                 console.log(item);
    //                 this.files.push(this.fileToJson(item));
    //                 this.refreshStorage();
    //             });
    //             return false;
    //         }
    //     }
    // },
    fileToJson: function(file, createObjectUrl = true){

        let object = {
            'name'       : file.name,
            'size'       : file.size,
            'type'       : file.type,
            'url'       : createObjectUrl ? URL.createObjectURL(file) : null,
            'lastModified'    : file.lastModified,
            'time' :  Math.round((new Date()).getTime() / 1000 ) //to record time of upload of each file
            // 'lastModifiedDate':  file.lastModifiedDate
        }
        // console.log( object.lastModifiedDate);
        // Object.assign(object.lastModifiedDate, new Date (file.lastModifiedDate));
        // console.log(object.lastModifiedDate);

        return object;
    },
    getFiles : function(){
        return this.files;
        // let filerKit = this.filer.prop("jFiler");
        // return filerKit.files_list;
    }
}
fileuploader.init();