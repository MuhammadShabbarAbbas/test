//Referenece : https://www.jqueryscript.net/layout/jQuery-Plugin-for-Tree-Widget-jqTree.html
var hierarchy = {

    data : null, 

    $tree : $('#hierarchyTree'), 

    $input : $('#addHierarchy'), 

    $button : $('#addHierarchyBtn'),

    $categories : null,

    $populateHierarchy : $('#populateHierarchy'),

    init : function(){

        chrome.runtime.sendMessage(
            {
                type: 'GETCATEGORIES',
                payload: {}
            },
            response => {
                if (response.success == true) {
                    DEBUG ? console.log(response.payload) : "";
                    this.$categories = response.payload;
                    this.$input.autocomplete({ source:  this.$categories.map( a => a.name )   }); //response.payload.name
                    this.$populateHierarchy.removeAttr('disabled');
                    this.$button.removeAttr('disabled');
                }
                else {
                    errorLog(response.payload);
                }
            }
        );


        nodesStorage.get(data => {
            if (typeof data != 'undefined' && data != '')
                this.data = data;
            $("#hierarchyTree").tree({
                data: this.data,
                autoOpen: true,
                dragAndDrop: true
            });
        });

        this.bindEvents();
    }, 
  
    bindEvents : function(){
        /**
         * Remove node on delete or backspace
         */
        this.$tree.keydown(function(event){
            var key = event.keyCode || event.charCode;
            if( key == 8 || key == 46 )
            {
                var node = this.$tree.tree('getSelectedNode');
                this.$tree.tree('removeNode', node);
                nodesStorage.set(JSON.parse(this.$tree.tree('toJson')), () => {/*No any callback for now*/});
            }
        }.bind(this));

        /**
         * Add node on enter click
         */
        this.$input.keydown(function(event){
            var key = event.keyCode || event.charCode;
            if( key == 13)
            {
                this.addNode();        
            }
        }.bind(this));

        this.$button.click(function(){
            this.addNode();        
        }.bind(this));
                
        this.$tree.bind(
            'tree.move',
            function(event)  {
                //Wraped in timeout as without timeout the json wasn't updated.
                setTimeout(()=>{
                    let json = JSON.parse(this.$tree.tree('toJson'));
                    nodesStorage.set( json, () => {
                        DEBUG ? console.log(json) : "";
                    });
                    }, 100);

                // if(event.move_info.position != "inside"){
                //     event.preventDefault();
                //     errorLog("You can only drag inside.")
                // }
                // console.log('current_parent', event.move_info.moved_node.parent);
                // console.log('moved_node', event.move_info.moved_node);
                // console.log('target_node', event.move_info.target_node);
                // console.log('position', event.move_info.position);
                // console.log('previous_parent', event.move_info.previous_parent);
            }.bind(this));


        /**set populate tags button action */
        this.$populateHierarchy.click(function () {
            nodesStoragePrev.get(data => {
                if (typeof data !== 'undefined' && data != "") {
                    data = this.updateJsonOnPopulate(data);
                    $("#hierarchyTree").tree('loadData', data);
                    nodesStorage.set(data, () => {/*No any callback for now*/});
                }
            });
        }.bind(this));
    },

    updateJsonOnPopulate : function(data){
        DEBUG ? console.log(data) : "";
        data.forEach( (val, index) => {
           if(this.$categories){
               var cat = this.$categories ? this.$categories.find(x => x.name === data[index].category) : null;
               var count = 0;
               if(cat) count = cat.count;
               data[index].name = data[index].category + " (" + count + ")";

               if(data[index].children) return this.updateJsonOnPopulate(data[index].children);
           }
        });
        DEBUG ? console.log(data) : "";
        return data;
    },

    /**
     * validate json to avoid any siblings at any level
     * @param {*} obj 
     */
    haveSiblings: function (obj) {
        
        // for (let k in obj) {
            if(typeof obj === 'undefined') return false;

            if(obj.length > 1){
                return true;
                // console.log("error : siblings found"  );
                // console.log(obj);
            }
            else if(obj.length == 1){
                // console.log("current object : " );
                // console.log(obj[0]);
                return this.haveSiblings(obj[0].children);
            }
            // else{
            //     return true;
            // }
            // if (typeof obj[k] === "object") {
            //     this.parseJson(obj[k]);
            // } else {
            //     // base case, stop recurring
            //     console.log(obj[k]);
            // }
        // }
    },

    getJson : function(){
        var json  = JSON.parse(this.$tree.tree('toJson')) ;
        // console.log(json);
        if(this.haveSiblings(json))
            return false;
        return json;
    },

    addNode : function(){
        if( this.$input.val() ) {
            var node = this.$tree.tree('getSelectedNode');
            var id = Math.round((new Date()).getTime() / 1000);
            var cat = this.$categories ? this.$categories.find(x => x.name === this.$input.val()) : null;
            var count = 0;
            if(cat) count = cat.count;

            this.$tree.tree(
                'appendNode',
                {
                    label: this.$input.val() + " (" + count + ")"  ,
                    id:  Math.round((new Date()).getTime() / 1000),
                    category : this.$input.val()
                },
                node
            );
            this.$tree.tree('selectNode', this.$tree.tree('getNodeById', id));

            nodesStorage.set(JSON.parse(this.$tree.tree('toJson')), () => {/*No any callback for now*/
                DEBUG ? console.log(JSON.parse(this.$tree.tree('toJson') )) : "";
            });

            this.$input.val("");
            this.$input.focus();
        }        
    }
}

hierarchy.init();