var transcribe = {
    init: function () {
        this.bindEvents();
    },

    bindEvents: function () {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.type === 'TRANSCRIBE') {
                // Log message coming from the `request` parameter
                // Send a response message
                var url = request.payload.url;
                this.getTranscript(url).then((response) => {
                    sendResponse({
                        success: true,
                        payload: response
                    });
                }).catch((error) => {
                    sendResponse({
                        success: false,
                        payload: error
                    });
                });
                return true;
            }
        }).bind(this);
    },

    /**to get Transcribe from IBM watson**/
    getTranscript: function (url) {
        return new Promise(function (resolve, reject) {
            
            var xhr = new XMLHttpRequest();
            xhr.withCredentials = true;
            xhr.addEventListener("readystatechange", function () {
                if (this.readyState === 4) {
                    var parsedData = JSON.parse(this.responseText);
                    var html = "";
                    if (typeof parsedData.results != 'undefined' && parsedData.results != null) {
                        parsedData.results.forEach(result => {
                            result.alternatives.forEach(payload => {
                                html += "<p>" + payload.transcript + "</p>";
                            });
                        });
                    }
                    resolve(html);
                }
            });
            xhr.open("POST", IBMURL);
            xhr.setRequestHeader("Authorization", IBMAUTH);
            xhr.setRequestHeader("Content-Type", "audio/webm");
            fetch(url).then((r) => {
                r.blob().then((fetchedblob) => {
                    xhr.send(fetchedblob);
                });
            });
        });
    }
}
transcribe.init();
