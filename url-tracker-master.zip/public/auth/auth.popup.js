var auth = {
    loggedoutcontrols: null,
    loggedInControls: null,
    email: null,
    pass: null,
    logoutBtn: null,
    log: null,
    userNameDisplay: null,
    spinner: null,
    loginBtn: null,

    init: function () {
        this.userNameDisplay = document.querySelector('#userNameDisplay');
        this.loggedoutcontrols = document.querySelectorAll('.loggedoutcontrols');
        this.loggedInControls = document.querySelectorAll('.loggedInControls');
        this.email = document.querySelector('#webSrapperLoginEmail');
        this.pass = document.querySelector('#webSrapperLoginPass');
        this.logoutBtn = document.querySelector('#webSrapperLogoutBtn');
        
        this.spinner = document.querySelector('#webscrapper-spinner');
        this.loginBtn = document.querySelector('#webSrapperLoginBtn');
        this.bindEvents();
    },
    bindEvents: function(){
        document.addEventListener('DOMContentLoaded', (this.loadAuth).bind(this));
        this.loginBtn.onclick = (this.validateInputs).bind(this);
        this.logoutBtn.onclick = (this.logout).bind(this);
    },

    validateInputs: function () {
        if (this.email.value == '' || this.pass.value == '') {
            errorLog("Email ID and password are required");
            return;
        }
        
        /**
         * In progress is being called from here to only show in progress 
         * if person is trying to login right now
         */
        this.inProgress();

        this.login();
    },

    loadAuth : function(){
            this.loggedIn("[...]");
            this.login();
    },
   
    login: function () {

        // Communicate with background file by sending a message
        chrome.runtime.sendMessage(
            {
                type: 'LOGIN',
                payload: {
                    username: this.email.value,
                    password: this.pass.value
                }
            },
            response => {
                if (response.success == true) {
                    var token = response.payload.token;
                    var name = response.payload.name;
                    this.loggedIn(name);
                    successLog("");
                }
                else {
                    DEBUG ? console.log(response) : "";
                    errorLog(response.payload);
                    this.loggedOut();
                }
            }
        );
    },

    inProgress: function () {
        this.loggedInControls.forEach((item, index) => {
            item.style.display = "none";
        });

        this.loggedoutcontrols.forEach((item, index) => {
            item.style.display = "none";
        });

        this.spinner.style.display = "block";
        successLog("Logging in!");
    },

    loggedIn: function (name) {
        //do post login actions
        this.loggedInControls.forEach((item, index) => {
            item.style.display = "block";
        });

        this.loggedoutcontrols.forEach((item, index) => {
            item.style.display = "none";
        });

        /**
         * Init tags if logged in first time.
         */
        tags.status == false ? tags.init() : "";

        

        this.spinner.style.display = "none";

        this.userNameDisplay.innerHTML = "Welcome " + name + ",";
    },

    logout: function () {
        var token = "";
        authStorage.set(token, () => {
            this.loggedOut();
            successLog("logged out!");
        });
    },

    loggedOut: function () {
        //do post login actions

        this.loggedInControls.forEach((item, index) => {
            item.style.display = "none";
        });

        this.loggedoutcontrols.forEach((item, index) => {
            item.style.display = "block";
        });

        this.spinner.style.display = "none";
    }
}
auth.init();