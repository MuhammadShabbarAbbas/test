var auth = {
 

    init: function () {
        this.bindEvents();
    },

    bindEvents: function () {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.type === 'LOGIN') {
                DEBUG ? console.log("login request received"):"";
                // Log message coming from the `request` parameter
                // Send a response message
                var uname = request.payload.username;
                var pass = request.payload.password;
                this.getToken(uname, pass).then((token) => {
                    this.getUser(token).then(user => {
                        sendResponse({
                            success: true,
                            payload: {
                                token: token,
                                name: user.name
                            }
                        });
                    }).catch(error => {
                        DEBUG ? console.log(error) : "";
                        sendResponse({
                            success: false,
                            payload: 'Error in getting user Info'
                        });
                    });
                }).catch((error) => {
                    DEBUG ? console.log(error):"";
                    sendResponse({
                        success: false,
                        payload: error
                    });
                });
                return true;
            }
        });
    },
    /**Used by auth APIs to get current auth token*/
    getToken: function (uname, pass) {
        return new Promise( (resolve, reject) =>{
            // get token from storage
            authStorage.get(token => {
                // if token is not in storage then generate
                if ((typeof token == 'undefined' || token == '' || uname != '' || pass != '')) {
                    this.generateToken(uname, pass).then(response => {
                        DEBUG ? console.log("generated token :" + response.data.token):"";
                        validateToken(response.data.token).then(validation => {
                            DEBUG ? console.log(validation) : "";
                            if (validation.success == true) {
                                authStorage.set(response.data.token, () => {
                                    //do post login actions
                                    resolve(response.data.token);
                                });
                            }
                            else {
                                var errorMsg = "Error in token validation";
                                reject(errorMsg);
                            }
                        }).catch(error => {
                            var errorMsg = "Error in token validation";
                            reject(errorMsg);

                        });
                    }).catch(error => {
                        var errorMsg = "Invalid ID or password";
                        reject(errorMsg);
                    });
                }
                //if token is already there, then validate
                else {
                    validateToken(token).then(validation => {
                        if (validation.success == true) {
                            resolve(token);
                        }
                        else {
                            reject("Error in token validation");
                        }
                    }).catch(error => {
                        reject(error);
                    });
                }
            });

        });

    },

    getUser: function (validatedToken) {
        var auth = "Bearer " + validatedToken;
        var request = {
            method: 'POST',
            data: null,
            withCredentials: true,
            headers: [
                {
                    key: "authorization",
                    value: auth
                }
            ],
            url: APIURL + "/wp/v2/users/me"
        };
        return PromiseToSendXhr(request);
    },

    generateToken: function (username, password) {
        var data = new FormData();
        data.append("username", username);
        data.append("password", password);

        var request = {
            method: 'POST',
            data: data,
            headers: [],
            withCredentials: true,
            url: APIURL + "/jwt-auth/v1/token"
        };
        return PromiseToSendXhr(request);
    }

}

auth.init();



// function WatsonGetTokenFromAPI(apikey) {
//   return new Promise(function (resolve, reject) {
//     var xmlRequest = new XMLHttpRequest();
//     if (window.XMLHttpRequest) {
//       xmlRequest.open("POST", "https://iam.cloud.ibm.com/identity/token");
//       xmlRequest.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
//       xmlRequest.setRequestHeader("Accept", "application/json");
//       xmlRequest.setRequestHeader("access-control-allow-origin", "*");
//       xmlRequest.send(encodeURI("grant_type=urn:ibm:params:oauth:grant-type:apikey&apikey=" + apikey));

//       xmlRequest.onreadystatechange = function () {

//         if (xmlRequest.readyState == 4 && xmlRequest.status == 200) {

//           var parsedData = JSON.parse(xmlRequest.responseText)

//           resolve(parsedData.access_token);
//         }
//         if (xmlRequest.status != 200) {
//           reject("Cannot request api token");
//         }
//       }
//     }
//   });
// }


