var ocr = {
    perform : function(imageURL){
        return new Promise((resolve, reject) => {
            chrome.runtime.sendMessage(
                {
                    type: 'OCR',
                    payload: {
                        url: imageURL
                    }
                },
                text => {
                    resolve(text)
                });
        });
    }
}