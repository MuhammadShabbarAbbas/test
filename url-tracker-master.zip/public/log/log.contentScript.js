var log = {
  error: msg => {
    var errorEl = document.createElement("div");
    errorEl.innerHTML = "<div class='logpopup' style='position: fixed; top: 30px; right: 20px; z-index: 9999; padding: 8px; background-color: #fff2f2; border: 1px solid #f03e3e; border-radius: 2px; font-size: 12px; line-height: 16px; transition: opacity .3s linear;'>" + msg + ".</div>";
    document.body.appendChild(errorEl);
    setTimeout(function () {
      document.body.removeChild(errorEl);
    }, 3000);
  },
  success: msg => {
    var errorEl = document.createElement("div");
    errorEl.innerHTML = "<div style='position: fixed; top: 30px; right: 20px; z-index: 9999; padding: 8px; color: #155724; background-color: #d4edda; border: 1px solid ##c3e6cb; border-radius: 2px; font-size: 12px; line-height: 16px; transition: opacity .3s linear;'>" + msg + ".</div>";
    document.body.appendChild(errorEl);
    setTimeout(function () {
      document.body.removeChild(errorEl);
    }, 3000);
  }
};

