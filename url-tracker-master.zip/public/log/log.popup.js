function errorLog(text) {
  var log = document.querySelector('#log');
  log.innerHTML = text;
  log.style.color = "red";
  window.scrollTo(0,document.body.scrollHeight);

}

function successLog(text) {
  var log = document.querySelector('#log');
  log.innerHTML = text;
  log.style.color = "green";
}