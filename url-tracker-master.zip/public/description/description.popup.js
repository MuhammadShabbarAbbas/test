var description = {
    descriptionControl: null,
    init: function () {
        this.descriptionControl = jQuery("#descTxt");
        this.gatherValues();
        this.bindEvents();
    },
    bindEvents: function () {
        this.descriptionControl.change(() =>{
            descStorage.set(this.descriptionControl.val(), () => {/**silence is golden**/ });
        });
    },
    gatherValues: function () {
        /**
         * Gather description value
         */
        descStorage.get(description => {
            if (typeof description !== 'undefined') {
                this.descriptionControl.val(description);
            }
        });
    }
}
description.init();
