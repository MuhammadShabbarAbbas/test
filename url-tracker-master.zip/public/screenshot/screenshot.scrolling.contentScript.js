var screenShot = {
    init: function () {
        this.bindEvents();
    },
    bindEvents: function () {
        chrome.runtime.onMessage.addListener(function (request, sender, callback) {
            switch (request.msg) {
                case "getPageDetails":
                    var size = {
                        width: Math.max(
                            document.documentElement.clientWidth,
                            document.body.scrollWidth,
                            document.documentElement.scrollWidth,
                            document.body.offsetWidth,
                            document.documentElement.offsetWidth
                        ),
                        height: Math.max(
                            document.documentElement.clientHeight,
                            document.body.scrollHeight,
                            document.documentElement.scrollHeight,
                            document.body.offsetHeight,
                            document.documentElement.offsetHeight
                        )
                    };

                    chrome.extension.sendMessage({
                        "msg": "setPageDetails",
                        "size": size,
                        "scrollBy": window.innerHeight,
                        "originalParams": {
                            "overflow": document.querySelector("body").style.overflow,
                            "scrollTop": document.documentElement.scrollTop
                        }
                    });
                    break;

                case "scrollPage":
                    var lastCapture = false;


                    window.scrollTo(0, request.scrollTo);


                    // first scrolling
                    if (request.scrollTo === 0) {

                        document.querySelector("body").style.overflow = "hidden";
                    }

                    console.log(request.size.height + " <= " + window.scrollY +"+"+ request.scrollBy);

                    //it fails sometimes when we are on the bottom of page specially when there are only two scrolls
                    // if (request.size.height <= window.scrollY + request.scrollBy) {

                    // this is working for all but not in dashboard of wordpress - don't know why!
                    // if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {

                    //element.scrollTop - is the pixels hidden in top due to the scroll. With no scroll its value is 0.
                    var a = document.documentElement.scrollTop;
                    // element.scrollHeight - is the pixels of the whole div.
                    var b = document.documentElement.scrollHeight - document.documentElement.clientHeight;
                    //c will be always 1 if b==0 as b=0 means there is no scrollbar
                    var c = b==0 ? 1 : a / b
                    DEBUG ? console.log("C is (0-1) : " + a + "/" + b + c) : "";
                    //working on this one now
                    if (c === 1) {
                        lastCapture = true;
                        request.scrollTo = request.size.height - request.scrollBy;
                    }


                    //in timeout because some websites shows sticky on scroll, so hide after they were shown
                    setTimeout(()=>{

                        //only hide when not on the top
                        if(c > 0) this.hideSticky();

                        chrome.extension.sendMessage({
                            "msg": "capturePage",
                            "position": request.scrollTo,
                            "lastCapture": lastCapture
                        });

                    }, 100);




                    break;

                case "resetPage":
                    this.resetPage(request.originalParams);
                    break;

                case "showError":
                    errorLog("An internal error occurred while taking pictures.");

                    this.resetPage(request.originalParams);
                    break;
            }
        }.bind(this));
    },

    //https://github.com/eemeli/kill-sticky
    hideSticky : function(){
        // const elements = document.querySelectorAll('body *')
        // for (let i = 0; i < elements.length; i++) {
        //     const el = elements[i]
        //     const { display, position } = window.getComputedStyle(el)
        //     if ((position === 'fixed' || position === 'sticky') && display !== 'none') {
        //         el.parentNode.removeChild(el)
        //     }
        // }
        // const fix = '; overflow: visible !important; position: relative !important'
        // document.body.style.cssText += fix
        // document.documentElement.style.cssText += fix
        var i, elements = document.querySelectorAll('body *');
        //this one is working good - hide element now rather than removing
        for (i = 0; i < elements.length; i++) {
            if (["sticky", "fixed"].includes(getComputedStyle(elements[i]).position) && ["block"].includes(getComputedStyle(elements[i]).display) ) {
                // elements[i].parentNode.removeChild(elements[i]);
                elements[i].style.display = "none";
                elements[i].classList.add("co-was-hidden");
                // x.style.display = "block";
            }
        }
    },
    showHidden : function (){
        var i, elements = document.querySelectorAll('body *');
        //this one is working good - hide element now rather than removing
        for (i = 0; i < elements.length; i++) {
            if (elements[i].classList.contains('co-was-hidden')) {
                elements[i].style.display = "block";
                elements[i].classList.remove("co-was-hidden");
            }
        }
    },
    resetPage: function (originalParams) {
        window.scrollTo(0, originalParams.scrollTop);
        document.querySelector("body").style.overflow = originalParams.overflow;
        this.showHidden();
    }
}

screenShot.init();