var screenshot = {

    image : null,

    init: function () {
        this.bindEvents();
    },

    bindEvents : function(){
        jQuery('#imagePaste').on('paste', (this.paste).bind(this));
    },

    paste: function(ev) {
        /**reset image parameters*/
        jQuery('#imagePaste').val("");
        jQuery('#images').empty();

        this.image = null;

        var clipboardData = ev.originalEvent.clipboardData;
        if (clipboardData) {
            if (clipboardData.items.length == 0) {
                return;
            }

            jQuery.each(clipboardData.items,  (i, item) =>{
                if (item.type.indexOf("image") !== -1) {
                    this.insertBinaryImage(item.getAsFile());
                }
            });
            return false;
        }
    },

    // Inserts a base64-encoded image to the editor.
    insertBinaryImage: function (file) {
        var reader = new FileReader();
        reader.addEventListener('loadend',  () => {
            this.image = new Image();
            this.image.src = reader.result;
            jQuery('#images').empty().append(this.image);
            jQuery('#imagePaste').val("Image pasted successfully!");
        });
        reader.readAsDataURL(file);
    },

    getScreenshot : function(){
        return this.image;
    }
}
screenshot.init();