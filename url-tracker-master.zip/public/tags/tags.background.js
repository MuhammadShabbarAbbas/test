var tags = {
    
    init: function () {
        this.bindEvents();
    },

    bindEvents: function () {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.type === 'GETTAGS') {
                DEBUG ? console.log("get tags request received") : "";
                // Log message coming from the `request` parameter
                // Send a response message
                this.getTags().then((response) => {
                    var names = response.data;
                    DEBUG ? console.log(response) : "";
                    /**convert to array**/
                    // response.forEach(obj => {
                    //     names.push(obj.name);
                    // });
                    sendResponse({
                        success: true,
                        payload: names
                    });
                }).catch((error) => {
                    DEBUG ? console.log(error): "";
                    sendResponse({
                        success: false,
                        payload: error
                    });
                });
                return true;
            }
        });
    },

    getTags: function () {
        return new Promise(function (resolve, reject) {
            doValidatedAction(function (token) {
                var auth = "Bearer " + token;
                var request = {
                    method: 'GET',
                    data: null,
                    headers: [
                        {
                            key: "authorization",
                            value: auth
                        }
                    ],
                    url: APIURL + "/wp/v2/alltags"
                };
                DEBUG ? console.log("token validated. Sending get tags request.") : "";
                PromiseToSendXhr(request).then(response => {
                    resolve(response);
                }).catch(error => {
                    reject(error);
                });
            },
                function (error) {
                    DEBUG ? console.log("token invalidated") : "";
                    reject(error);
                });
        });
    }
}

tags.init();