var tags = {
    status : false,

    init: function () {
        this.bindEvents();
    },

    bindEvents: function () {
        chrome.runtime.sendMessage(
            {
                type: 'GETTAGS',
                payload: {}
            },
            response => {
                if (response.success == true) {
                    $('#url_tracker_tags').tagsInput({
                        'onAddTag': function (input, value) {
                            tagsStorage.get(ut_tags => {
                                if (typeof ut_tags == 'undefined') {
                                    tagsStorage.set(value, () => {/**silence is golden*/ });
                                }
                                else {
                                    tagsStorage.set(ut_tags + "," + value, () => {/**silence is golden*/ });
                                }
                            });
                        },
                        'onChange': function (input, value) {
                            if (Array.isArray(value)) {

                                var tbi = "";
                                value.forEach(function (item, index) {
                                    if (item !== '') { tbi += item + "," };
                                });
                                tagsStorage.set(tbi, () => {/**silence is golden*/ });
                            }
                        },
                        'onRemoveTag': function (input, value) {

                        },
                        'autocomplete': {
                            source: response.payload
                        }
                    });
                    this.status = true;

                    jQuery('#url_tracker_populate_tags').prop('disabled', false);

                    tagsStorage.get(ut_tags => {
                        if (typeof ut_tags !== 'undefined') {
                            jQuery('#url_tracker_tags').importTags(ut_tags);
                        }
                    });
                }
                else {
                    errorLog(response.payload);
                }
            }
        );

        /**set populate tags button action */
        jQuery('#url_tracker_populate_tags').click(function () {
            tagsStoragePrev.get(ut_tags_prev => {
                if (typeof ut_tags_prev !== 'undefined') {
                    jQuery('#url_tracker_tags').importTags(ut_tags_prev);
                }
            });
        });
    },
}
//to init tags directly - this will only run if the user is logged in already
tags.init();