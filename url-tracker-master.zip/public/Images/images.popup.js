var images = {

    uploader : null,
    images : [],

    init: function () {
        this.bindEvents();

        let self = this;
        imagesLocalStorage.get(data => {
            if (typeof data !== 'undefined' && data != "" && data != [] && Array.isArray(data))  {
                this.images = data;
            }

            this.uploader = jQuery('.input-images').imageUploader(
                {
                    extensions :  ['.jpg', '.jpeg', '.png', '.gif', '.svg'],
                    label: 'Drag & Drop files here or click to browse or press Ctrl+V anywhere to paste image from clipboard',
                    addImageCallback: (file) => {

                        let reader = new FileReader();
                        reader.addEventListener('loadend',  () => {
                            let dataUri =reader.result;
                            this.images.push( {id:this.randomPreloadID(), src: dataUri, time : Math.round((new Date()).getTime() / 1000) });
                            imagesLocalStorage.set(self.images, ()=>{});
                        });
                        reader.readAsDataURL(file);
                    },
                    delImageCallback : (id)=>{
                        this.images  = this.images.filter(function( obj ) {
                            return obj.id !== id;
                        });
                        imagesLocalStorage.set(this.images, ()=>{ /**No callback*/});
                    },
                    preloaded: this.images
                }
            );
        });
    },

    bindEvents : function(){
        jQuery(window).on('paste', (this.paste).bind(this));
    },

    paste: function(ev) {
            //condition to avoid text box and textare pastes
            if (!jQuery('input, textarea').is(ev.target)){

                var clipboardData = ev.originalEvent.clipboardData;
                if (clipboardData) {
                    if (clipboardData.items.length == 0) {
                        return;
                    }

                    jQuery.each(clipboardData.items,  (i, item) =>{
                        if (item.type.indexOf("image") !== -1) {
                            this.uploader.addImage([item.getAsFile()]);
                        }
                    });
                    return false;
                }
            }
    },

    // Generate a random id
    randomPreloadID : function () {
        return Date.now() + Math.floor((Math.random() * 100) + 1);
    }

}
images.init();