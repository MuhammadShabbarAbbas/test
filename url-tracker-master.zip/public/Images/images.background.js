var images ={
    init : function(){
        this.bindEvents();
    },
    bindEvents : function(){

        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.type === 'IMAGES_DATA_URL') {
                let blob = dataURItoBlob(request.payload.url);
                sendResponse({
                    payload: {url : blob}
                });
                DEBUG ? console.log(blob) : "";

                return true;
            }
        });


    }
}
images.init();