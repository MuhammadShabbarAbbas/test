/**
 * This script is used to keep the background script alive when persistence is off to perform longer tasks.
 * @type {{init: heartbeat.init, stop: heartbeat.stop, sendMessage: heartbeat.sendMessage, interval: null}}
 */
var heartbeat = {
    start : function(){
        chrome.tabs.getSelected(null, function (tab) {
            // console.log(tab.id);
            chrome.tabs.sendMessage(tab.id, {
                type: 'HEARTBEAT.START',
                payload: {}
            });
        });
    },
    stop: function (){
        chrome.tabs.getSelected(null, function (tab) {
            // console.log(tab.id);
            chrome.tabs.sendMessage(tab.id, {
                type: 'HEARTBEAT.STOP',
                payload: {}
            });
        });
    }
}
