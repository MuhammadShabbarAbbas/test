var heartbeat = {
    init: function () {
        this.bindEvents();
    },
    bindEvents: function () {
        chrome.runtime.onMessage.addListener( function(request, sender, sendResponse){
            if (request.type === 'HEARTBEAT') {
                DEBUG ? console.log('Heartbeat received') : "";
                    sendResponse({
                        success: true,
                        payload: null
                    });
                return true;
            }
        }.bind(this));
    }
}
heartbeat.init();