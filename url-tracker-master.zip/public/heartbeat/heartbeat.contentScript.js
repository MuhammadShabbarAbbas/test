/**
 * This script is used to keep the background script alive when persistence is off to perform longer tasks.
 * @type {{init: heartbeat.init, stop: heartbeat.stop, sendMessage: heartbeat.sendMessage, interval: null}}
 */
var heartbeat = {
    interval : null,
    init : function(){
        this.bindEvents();
    },
    start : function(){
        this.interval = setInterval(this.sendMessage, 1000);
    },
    bindEvents : function(){
        chrome.runtime.onMessage.addListener( function(request, sender, sendResponse){
            if (request.type === 'HEARTBEAT.START') {
                this.start();
                sendResponse({
                    success: true,
                    payload: {}
                });
                return true;
            }
            if (request.type === 'HEARTBEAT.STOP') {
                this.stop();
                sendResponse({
                    success: true,
                    payload: {}
                });
                return true;
            }


        }.bind(this));
    },
    sendMessage : function (){
        chrome.runtime.sendMessage(
            {
                type: 'HEARTBEAT',
                payload: {}
            },
            response => { });
    },
    stop: function (){
        clearInterval(this.interval);
    }
}
heartbeat.init();