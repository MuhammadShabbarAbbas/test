var doValidatedAction = (action, failcallback) => {
  this.authStorage.get(token => {
    this.validateToken(token).then(validation => {
      if (validation.success == true) {
        action(token);
      }
      else {
        failcallback("invalidated Token");
      }
    }).catch(error => {
      failcallback(error);
    })
  });
}

var validateToken = (token) => {
  var auth = "Bearer " + token;
  var request = {
    method: 'POST',
    data: null,
    withCredentials: true,
    headers: [
      {
        key: "authorization",
        value: auth
      }
    ],
    url: this.APIURL + "/jwt-auth/v1/token/validate"
  };

  return PromiseToSendXhr(request);
}

var PromiseToSendXhr = (request) => {

  return new Promise(function (resolve, reject) {
    var headers = new Headers();
    request.headers.forEach((header) => {
      headers.append(header.key, header.value);
    });


    var requestOptions = {
      method: request.method,
      headers: headers,
      body: request.data,
      redirect: 'follow'
    };


    fetch(request.url, requestOptions)
      .then(response => response.text())
      .then(data => {
        DEBUG ? console.log(data) : "";
        var parsedData = JSON.parse(data);
        resolve(parsedData);
      })
      .catch(error => {
        reject(error);
      });
  });

  // return new Promise(function (resolve, reject) {
  //   var xmlRequest = new XMLHttpRequest();
  //   if (window.XMLHttpRequest) {
  //     xmlRequest.open(request.method, request.url, true);
  //     request.headers.forEach((header) => {
  //       xmlRequest.setRequestHeader(header.key, header.value);
  //     });
  //     xmlRequest.timeout = 180000;
  //     xmlRequest.withCredentials = request.withCredentials != 'undefined' && request.withCredentials === true ? true : false;
  //     xmlRequest.cache = false;
  //     xmlRequest.contentType = false;
  //     xmlRequest.processData = false;
  //     xmlRequest.send(request.data);

  //     xmlRequest.onreadystatechange = function () {
  //       if (xmlRequest.readyState == 4 && (xmlRequest.status == 200 || xmlRequest.status == 201)) {
  //         DEBUG ? console.log(xmlRequest.responseText) : "";
  //         var parsedData = JSON.parse(xmlRequest.response);
  //         resolve(parsedData);
  //       }
  //       else if (xmlRequest.status != 200 && xmlRequest.status != 201) {
  //         reject(xmlRequest.status);
  //       }
  //     }
  //   }
  // });
}
