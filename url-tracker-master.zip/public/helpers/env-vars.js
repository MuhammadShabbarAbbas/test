DEBUG = true;

APIURL = "https://captureone.kinsta.cloud/wp-json";
IBMURL = "https://api.us-east.speech-to-text.watson.cloud.ibm.com/instances/f728e5e1-3a51-4946-bd30-d7569743503c/v1/recognize"; //?timestamps=true&speaker_labels=true
IBMAUTH = "Basic YXBpa2V5OnZvN1RHdE9aeWV4SjBtOGlHWGY4Y3ZReXRHTF85SFdYanlTeUpqSExMSGtr";
// OCR_SPACE_API_KEY = "105071087388957";
OCR_SPACE_API_URL = "https://apipro1.ocr.space/parse/image"
OCR_SPACE_API_KEY = "PR8DGKBTLF5X";
