var ut_tags_prev = 'ut_tags_prev';
var ut_tags = 'ut_tags';
var ut_status = 'ut_status';
var ut_desc = 'ut_desc';
var ut_auth = 'ut_auth';
var ut_nodes = 'ut_nodes';
var ut_nodes_prev = 'ut_nodes_prev';
var ut_images = 'ut_images';
var ut_file = 'ut_file';


var filesStorage = {
  get: cb => getter(cb, this.ut_file),
  set: (value, cb) => setter(cb, { ut_file : value }),
};

var descStorage = {
  get: cb => getter(cb, this.ut_desc),
  set: (value, cb) => setter(cb, { ut_desc : value }),
};

var statusStorage = {
  get: cb => getter(cb, this.ut_status),
  set: (value, cb) => setter(cb, { ut_status: value }),
};

var tagsStorage = {
  get: cb => getter(cb, this.ut_tags),
  set: (value, cb) => setter(cb, { ut_tags: value }),
};

var tagsStoragePrev = {
  get: cb => getter(cb, this.ut_tags_prev),
  set: (value, cb) => setter(cb, { ut_tags_prev: value }),
};

var authStorage = {
  get: cb => getter(cb, this.ut_auth),
  set: (value, cb) => setter(cb, { ut_auth: value }),
};

var nodesStorage = {
  get: cb => getter(cb, this.ut_nodes),
  set: (value, cb) => setter(cb, { ut_nodes: value }),
};

var nodesStoragePrev = {
  get: cb => getter(cb, this.ut_nodes_prev),
  set: (value, cb) => setter(cb, { ut_nodes_prev: value }),
};


var imagesStorage = {
  get: cb => getter(cb, this.ut_images),
  set: (value, cb) => setter(cb, { ut_images: value }),
};


var imagesLocalStorage = {
  get: cb => Lgetter(cb, this.ut_images),
  set: (value, cb) => Lsetter(cb, { ut_images: value }),
  clear : (successCB, errorCB) => Lclear(successCB, errorCB, this.ut_images)
};

function Lclear( scb, ecb , key ){
  chrome.storage.local.remove([key],function(){
    var error = chrome.runtime.lastError;
    if (error) {
      ecb(error);
    }
    else{
      scb();
    }
  });
}


function LClear(cb, key) {
  chrome.storage.local.get([key], result => {
    cb(result[key]);
  });
};

function Lgetter(cb, key) {
  chrome.storage.local.get([key], result => {
    cb(result[key]);
  });
};

function Lsetter(cb, object) {
  chrome.storage.local.set(
      object,
      () => {
        cb();
      }
  );
};


function getter(cb, key) {
  chrome.storage.sync.get([key], result => {
    cb(result[key]);
  });
};

function setter(cb, object) {
  chrome.storage.sync.set(
    object,
    () => {
      cb();
    }
  );
};



function Lgetter(cb, key) {
  chrome.storage.local.get([key], result => {
    cb(result[key]);
  });
};

function Lsetter(cb, object) {
  chrome.storage.local.set(
      object,
      () => {
        cb();
      }
  );
};