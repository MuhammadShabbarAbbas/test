var uploader = {
  init: function () {
    this.bindEvents();
  },
  bindEvents: function () {
    chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
      if (request.type === 'UPLOAD_IN_NEW_TAB') {
        chrome.tabs.create({
          // Just use the full URL if you need to open an external page
          url: chrome.runtime.getURL("uploader.html")
        }, function (tab) {
          chrome.tabs.onUpdated.addListener(function listener(tabId, changeInfo) {
            if (tabId === tab.id && changeInfo.status == 'complete') {
              chrome.tabs.onUpdated.removeListener(listener);
              // Now the tab is ready!
              chrome.tabs.sendMessage(tab.id, {
                msg: "UPLOAD",
                CAPTURE: request.CAPTURE,
                tabUrl: request.tabUrl,
                description: request.description,
                tagsInput: request.tagsInput,
                textversion: request.textversion,
                screenshot: request.screenshot,
                images : request.images,
                imagesTimes : request.imagesTimes,
                ocr: request.ocr,
                elapsedtime: request.elapsedtime,
                hierarchy : request.hierarchy,
              });
            }
          });
        });
        return true;
      }
    }.bind(this));
  }
}
uploader.init();