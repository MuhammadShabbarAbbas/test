
function successLog(msg) {
    var errorEl = document.createElement("div");
    errorEl.innerHTML = "<div style='padding: 8px; color: #155724; background-color: #d4edda; border: 1px solid ##c3e6cb; border-radius: 2px; font-size: 12px; line-height: 16px; transition: opacity .3s linear;'>" + getLogTime() + ": " + msg + ".</div>";
    document.body.appendChild(errorEl);
}

function errorLog(msg) {
    var errorEl = document.createElement("div");
    errorEl.innerHTML = "<div style='padding: 8px; background-color: #fff2f2; border: 1px solid #f03e3e; border-radius: 2px; font-size: 12px; line-height: 16px; transition: opacity .3s linear;'>" + getLogTime() + ": " + msg + ".</div>";
    document.body.appendChild(errorEl);

    var retryEl = document.createElement("div");
    retryEl.innerHTML = "<button class='m-3 retry-btn btn btn-primary ml-1'>Retry</button>";
    document.body.appendChild(retryEl);
}

function getLogTime() {
    var today = new Date();
    var date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var dateTime = date + ' ' + time;
    return dateTime;
}