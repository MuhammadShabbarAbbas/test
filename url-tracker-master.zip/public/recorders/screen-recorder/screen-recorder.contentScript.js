/**
 * To store URLs in content script so that each content script has it's own recording url
 */
var Recorder = {
    winID : null,
    init : function(){
        // this.bindEvents();
        this.getStatus();
    },
    /**
     * @since 1.3.3
     * Commented to implement heartbeat logic
     */
    // bindEvents : function () {
        // chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
        //     switch (request.msg) {
        //         case "SET_WIN_ID":
        //             this.winID = request.value;
        //             break;
        //         case "GET_WIN_ID":
        //             chrome.extension.sendMessage({
        //                 "msg": "WIN_ID",
        //                 "value": this.winID,
        //             });
        //             break;
        //     }
        // }.bind(this));
    // },
    getStatus: function () {
        chrome.runtime.sendMessage(
            {
                type: 'TABRECORDER.STATUS',
                payload: {}
            },
            response => {
                if(response.status == true){
                    heartbeat.start();
                }
            });
    }
}
//trying to do store winID in background script
Recorder.init();