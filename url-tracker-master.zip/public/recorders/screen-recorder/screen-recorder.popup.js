var screenRecorder = {
    startBtn: document.getElementById('url-tracker-start-screen-recording'),
    stopBtn: document.getElementById('url-tracker-stop-screen-recording'),
    elementRecorderControls: document.querySelector('.url-tracker-element-recording-controls-container'),

    acknowledgments: {},
    port: null,

    init: function () {
        this.getStatus().then(isRunning => {
            if (isRunning) this.running();
        });
        this.port = chrome.runtime.connect();
        this.makeAcknowledgements();
        this.bindEvents();
    },

    makeAcknowledgements: function () {
        
        // this variable will be unique callback idetifier
        // You create acknowledgment by identifying callback
        this.acknowledgments['CAPTURE_TAB'] = (data) => {
            // callback function
            this.running();
            if (data == true) {
                // this.running();
                successLog("Tab capture started...");
                // as it is reported that if you drag chrome screen's status-bar
                // and scroll up/down the screen-viewer page.
                // chrome auto-stops the screen without firing any 'onended' event.
                // chrome also hides screen status bar.
                heartbeat.start();
                close();
                return;
                /**
                 * @since 1.3.4
                 * Unreachable code below after implementation of heartbeat
                 */
                chrome.windows.create({
                    url: chrome.extension.getURL('_generated_background_page.html'),
                    type: 'popup',
                    focused: false,
                    width: 1,
                    height: 1,
                    top: parseInt(screen.height),
                    left: parseInt(screen.width)
                }, function (win) {
                    chrome.extension.sendMessage({
                        msg: "SET_WIN_ID",
                        value: win.id
                      });
                      /**
                       * Close window on tab capture starts
                       * not closing window creating issues.
                       */
                        close();

                });
            }
            else {
                /**
                 * This.stopped closes previous
                 */
                // this.stopped(null);
                errorLog("Cannot start consecutive tab captures...");
            }
            // do what you like with result dataf
        };

        this.acknowledgments['STOP_CAPTURE'] =  (capture) => {
            heartbeat.stop();
            this.stopped(capture);
        };

    },

    bindEvents: function () {
        /**
        * To remove win when scren recording stops
        */
        /**
         * @since 1.3.4
         * commented to test heartbeat logic
         */
        // chrome.runtime.onMessage.addListener(function (request, sender, callback) {
        //     switch (request.msg) {
        //         case "WIN_ID":
        //             if (request.value != null) chrome.windows.remove(request.value);
        //             break;
        //     }
        // }.bind(this));

        this.port.onMessage.addListener(function (message) {
            var callback = this.acknowledgments[message.acknowledgment];
            if (callback) {
                callback(message.data);
                // don't forget to unset acknowledgment, because it's 
                // supposed to exists only until it's been called.
                delete this.acknowledgments[message.acknowledgment];
                return;
            }
            // other message types handling
        }.bind(this));

        this.startBtn.onclick = (this.start).bind(this);
        this.stopBtn.onclick = (this.stop).bind(this);

    },

    getStatus: function () {
        return new Promise((resolve, reject) => {
            chrome.tabs.getSelected(null, (tab) => {
                chrome.tabCapture.getCapturedTabs(
                    function (tabs) {
                        tabs.forEach((item, index) => {
                            if (item.tabId == tab.id && item.status == "active") {
                                resolve(true);
                            }
                        });
                        resolve(false);
                    });
            });
        });
    },

    start: function () {
        // port = chrome.runtime.connect();
        this.port.postMessage({
            acknowledgment: 'CAPTURE_TAB',
            data: {}
        });
    },

    running: function () {
        /**Do UI related stuff**/
        this.startBtn.disabled = true;
        this.stopBtn.disabled = false;
        this.elementRecorderControls.style.display = "none";
        successLog("Tab capture in progress...");
    },

    stop: function () {
        this.port.postMessage({
            acknowledgment: 'STOP_CAPTURE',
            data: {}
        });
    },


    stopped: function (capture) {

        /**
         * set capture url in content script
         */
        stopCallback(capture);

        /**
         * Get win id to close that win
         * Reception action of this message can be found above in bind Events method
         */
        // chrome.tabs.getSelected(null, function (tab) {
        //     chrome.tabs.sendMessage(tab.id, {
        //         msg: "GET_WIN_ID"
        //     });
        // });
        /**
         * send to background script rather than content script
         */
        /**
         * @since version 1.3.4
         * commented to test heartbeat logic
         */
        //
        // chrome.extension.sendMessage({
        //     "msg": "GET_WIN_ID",
        //   });

        /**
         * UI actions
         */
        this.startBtn.disabled = false;
        this.stopBtn.disabled = true;
        this.elementRecorderControls.style.display = "block";
        successLog("Tab capture stopped...");
    }
}
screenRecorder.init();