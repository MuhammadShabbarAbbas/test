/**
 * Used by pop up to send message to content script to store recording capture
 * These messages are used by both element and screen recorder
 * @param {*} capture 
 */
var stopCallback=(capture)=>{
    chrome.tabs.getSelected(null, function (tab) {
        chrome.tabs.sendMessage(tab.id, {
          "msg": "SET_CAPTURE",
          "value": capture
        });
      });
}