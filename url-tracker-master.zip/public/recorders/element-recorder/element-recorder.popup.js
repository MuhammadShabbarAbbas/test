var elementRecoding = {
  
  status: false,

  screenRecorderControls: null,

  startButton: null,

  stopButton: null,


  init: function () {
    this.screenRecorderControls = document.querySelector('.screen-recording-controls-container');
    this.startButton = document.getElementById("startElementRecordBtn");
    this.stopButton = document.getElementById("stopElementRecordBtn");
    this.bindEvents();
    this.askStatus();
  },

  bindEvents: function () {
    //listen to element recording related messages
    chrome.runtime.onMessage.addListener(function (request, sender, callback) {
      switch (request.msg) {
        /**
         * Automatically set controls state 
         * This message is a reply of get status
         */
        case "ELEMENT_RECORDING_STATUS":
          request.value == true ? this.isRunning() : this.isNotRunning();
          break;
          /**
           * This message is received when recording is stopped.
           */
        case "ELEMENT_RECORDING":
          stopCallback(request.value);
          break;
      }
    }.bind(this));

    this.startButton.addEventListener("click", this.activate_inspector.bind(this));

    this.stopButton.addEventListener("click", this.stop.bind(this));
  },

  activate_inspector: function() {


    chrome.tabs.getSelected(null, (tab) =>{

      if(tab.status !== "complete") {
        errorLog("Cannot start element recording when page is loading...");
        return;
      }

      chrome.tabs.sendMessage(tab.id, {
        "msg": "ACTIVATE_INSPECTOR"
      });


      this.isRunning();
      /**
       * to close pop up window after turning on the inspector mode
       */
      window.close();
    });
  },

  askStatus: function () {
    chrome.tabs.getSelected(null, function (tab) {
      chrome.tabs.sendMessage(tab.id, {
        "msg": "IS_ELEMENT_RECORDING"
      });
    });
  },

  isRunning: function () {
    this.startButton.disabled = true;
    this.stopButton.disabled = false;
    this.screenRecorderControls.style.display = "none";
    this.status = true;
  },

  stop: function () {
    chrome.tabs.getSelected(null,  (tab) => {
      chrome.tabs.sendMessage(tab.id, {
        "msg": "STOP_ELEMENT_RECORDING"
      });
      this.isNotRunning();
    });
  },

  isNotRunning: function () {
    this.startButton.disabled = false;
    this.stopButton.disabled = true;
    this.screenRecorderControls.style.display = "block";
    this.status = false;
  },

  /**
   * This function will be used by submit handler to see if recording is currently running or not
   * @returns true or false
   */
  getStatus: function () {
    return this.status;
  }
}

elementRecoding.init();