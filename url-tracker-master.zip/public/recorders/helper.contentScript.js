/**
 * To store URLs in content script so that each content script has it's own recording url
 */
/**
 * These messages are used by both element and screen recorder
 */
var recorderHelper = {

    capture : null,
    init : function(){
        this.bindEvents();
    },
    
    bindEvents : function(){
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse)  {
            switch (request.msg) {
                case "SET_CAPTURE":
                    this.capture = request.value;
                    DEBUG ? console.log(this.capture) : "";
                    break;
                case "GET_CAPTURE":
                    DEBUG ? console.log(this.capture)  : "";
                    chrome.extension.sendMessage({
                        "msg": "CAPTURE",
                        "value": this.capture,
                    });
                    /**DELETE capture url for those pages which have */
                    this.capture = null;
                    break;
            }
        }.bind(this));
    }
}
recorderHelper.init();