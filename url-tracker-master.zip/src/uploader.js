var uploader = {

    request  : null,

    init: function () {
        this.bindEvents();
    },
    bindEvents: function () {
        chrome.runtime.onMessage.addListener(function (request, sender, callback) {
            switch (request.msg) {
                case "UPLOAD":
                    this.request = request;
                    document.getElementById('title').innerHTML = 'Upload progress for ' + request.tabUrl;
                    this.upload();
                    break;
            }
        }.bind(this));

        jQuery(document).ready(()=>{
            jQuery('body').on('click', '.retry-btn', function() {
                jQuery(".retry-btn").remove();
                this.upload();
            }.bind(this));
        });
    },

    upload : function(){
        successLog('Performing OCR...');
        ocr.perform(this.request.screenshot).then(ocr => {
            DEBUG ? console.log( ocr.payload) : "";
            if(ocr.success == false) {
                errorLog("OCR failed...");
                return;
            }

            if (this.request.CAPTURE != null) {
                successLog('Generating transcript...');
                DEBUG ? console.log(this.request.CAPTURE) : "";
                DEBUG ? console.log(this.request.screenshot) : "";
                this.getTranscript(this.request.CAPTURE[0]).then((html) => {
                    let data = {
                        transcript: html,
                        video: this.request.CAPTURE[1],
                        videoStartTime: this.request.CAPTURE[2],
                        videoStopTime: this.request.CAPTURE[3],
                        url: this.request.tabUrl,
                        content: this.request.description,
                        tags: this.request.tagsInput,
                        textversion:  ocr.payload,
                        ocr: this.request.textversion,
                        screenshot: this.request.screenshot,
                        images : this.request.images,
                        imagesTimes : this.request.imagesTimes,
                        elapsedtime: this.request.elapsedtime,
                        hierarchy : this.request.hierarchy
                    }
                    this.uploadData(data);
                }).catch(error => errorLog('Error in generating transcript...'));
            }
            else {
                let data = {
                    url: this.request.tabUrl,
                    content: this.request.description,
                    tags: this.request.tagsInput,
                    textversion: this.request.textversion,
                    ocr: ocr.payload,
                    screenshot: this.request.screenshot,
                    images : this.request.images,
                    imagesTimes : this.request.imagesTimes,
                    elapsedtime: this.request.elapsedtime,
                    hierarchy : this.request.hierarchy
                }
                this.uploadData(data);
            }
        });
    },

    uploadData: function (data) {
        successLog('uploading data...');
        this.createCapture(data).then((response) => {
            successLog("done uploading... closing...");
            setTimeout(() => {
                if(!DEBUG) close();
            }, 5000);
        }).catch((error) => {
            errorLog(error);
            DEBUG ? console.log(error) : "";
        });
    },

    createCapture: function (payload) {
        return new Promise(function (resolve, reject) {
            doValidatedAction(function (token) {
                var auth = "Bearer " + token;
                var data = new FormData();
                data.append("url", payload.url);
                data.append("content", payload.content);
                data.append("tags", payload.tags);

                data.append("textversion", payload.textversion);
                data.append("ocr", payload.ocr);
                data.append("elapsedtime", payload.elapsedtime);
                data.append("hierarchy", payload.hierarchy);


                DEBUG ? console.log("hierarchy : " + payload.hierarchy) : "";

                var unixName = Math.round((new Date()).getTime() / 1000);
                DEBUG ? console.log("file name : " + unixName) : "";

                DEBUG ? console.log(payload.screenshot) : "";

                /**
                 * Data uri of screenshot will be received. 
                 * Convert it to blob. 
                 */
                var screenshot = new File([dataURItoBlob(payload.screenshot)], unixName + ".png", {
                    type: "image/png"
                });
                data.append("screenshot", screenshot);

                    /**
                     * append optional images
                     */
                    if(Array.isArray(payload.images)){

                        payload.images.forEach((image, index) => {
                            data.append("images[]",  new File([dataURItoBlob(image)], unixName + ".png", {
                                type: "image/png"
                            }));

                            data.append("imagesTimes[]", payload.imagesTimes[index] );
                        });

                        // DEBUG ? console.log(images) : "";
                    };

                if (typeof payload.video != 'undefined' && payload.video != '') {
                    /**
                     * URL of video will be supplied
                     */
                    fetch(payload.video).then(r => {
                        r.blob().then(blob => {
                            var video = new File([blob], unixName + ".webm", {
                                type: "video/webm"
                            });
                            data.append("video", video);
                            data.append("videoStartTime", payload.videoStartTime);
                            data.append("videoStopTime", payload.videoStopTime);
                            data.append("transcript", payload.transcript);
                            sendRequest();
                        });
                    });
                }
                else {
                    sendRequest();
                }

                function sendRequest() {
                    var request = {
                        method: 'POST',
                        data: data,
                        headers: [
                            {
                                key: "authorization",
                                value: auth
                            }
                        ],
                        url: APIURL + "/wp/v3/capture"
                    };
                    DEBUG ? console.log("token validated. Sending capture create request") : "";
                    PromiseToSendXhr(request).then(response => {
                        DEBUG ? console.log(response) : "";
                        if(response.statusCode != 200){
                            reject(response.message);
                        }
                        resolve(response);
                    }).catch(error => {

                        reject(error);
                    });
                }
            },
                function (error) {
                    DEBUG ? console.log("token invalidated") : "";
                    reject(error);
                });
        });
    },

    /**to get Transcribe from IBM watson**/
    getTranscript: function (url) {
        return new Promise(function (resolve, reject) {

            fetch(url).then((r) => {
                r.blob().then((fetchedblob) => {
                    var myHeaders = new Headers();
                    myHeaders.append("Authorization", IBMAUTH);
                    myHeaders.append("Content-Type", "audio/webm");

                    var file = fetchedblob;

                    var requestOptions = {
                    method: 'POST',
                    headers: myHeaders,
                    body: file,
                    redirect: 'follow'
                    };

                    fetch(IBMURL, requestOptions)
                        .then(response =>  response.text())
                        .then(data => {
                            // DEBUG ? console.log(this.responseText) : "";
                            var parsedData = JSON.parse(data);
                            var html = "";
                            if (typeof parsedData.results != 'undefined' && parsedData.results != null) {
                                parsedData.results.forEach(result => {
                                    result.alternatives.forEach(payload => {
                                        html += "<p>" + payload.transcript + "</p>";
                                    });
                                });
                            }
                            resolve(html);
                        })
                    .catch(error => {
                        DEBUG ? console.log(error) : "";
                        reject(error);
                    });
                }).catch(error => {
                    DEBUG ? console.log(error) : "";
                    reject(error);
                })
            }).catch(error => {
                DEBUG ? console.log(error) : "";
                reject(error);
            });
        });
    }
}
uploader.init();

