'use strict';

import './popup.css';
var popup = {

  submitBtn: jQuery('#submitBtn'),

  descControl: jQuery("#descTxt"),
  Timer: require('./timer/timer.popup'),
  textVersion: null,
  tagsInput: null,
  images: [],
  imagesTimes: [],
  files: [],
  filesTimes: [],
  ipAddress : null,
  hirarky : null,
  /**
   * keeps track of content page load
   */
  loadend : false,

  init: function () {
    /**
     * initiating timer from here because timer requires a node module
     */
    this.Timer.timer.init();

    this.bindEvents();
  },
  bindEvents: function () {

    chrome.runtime.onMessage.addListener(function (request, sender, callback) {
      switch (request.msg) {
        case "TEXT_VERSION":
          this.textVersion = request.value;
          successLog("getting capture url..");
          this.sendMessage('GET_CAPTURE');
          break;

        case "CAPTURE":
          successLog("taking screenshot");

          chrome.tabs.getSelected(null, (tab) => {
            ScrollingScreenshot.capture(imageUri => {
                chrome.extension.sendMessage({
                  type: "UPLOAD_IN_NEW_TAB",
                  CAPTURE: request.value,
                  tabUrl: tab.url,
                  description: this.descControl.val(),
                  tagsInput: this.tagsInput,
                  textversion: this.textVersion,
                  screenshot: imageUri, //this.image.src,
                  images : this.images,
                  imagesTimes : this.imagesTimes,
                  ocr: this.textVersion, //TODO : remove this argument as we will OCR directly on upload now
                  elapsedtime: this.Timer.timer.time(),
                  hierarchy : JSON.stringify(this.hirarky)
                });
                this.Timer.timer.reset();
            });
          });
          break;
      }
    }.bind(this));

    this.submitBtn.click(this.submit.bind(this));
  },

  tabStatus : function(){
    return new Promise( function(resolve,reject){
      chrome.tabs.getSelected(null, (tab) => {
        DEBUG ? console.log(tab.status) : "";
        if (tab.status == "complete") resolve(true);
        resolve(false);
      })
    });
  },
  submit: async function () {
    
    await this.tabStatus().then(status => this.loadend = status);

    // await chrome.tabs.getSelected(null, (tab) => {
    //     DEBUG ? console.log(tab.status): "";
    //     if(tab.status == "complete") this.loadend = true;
    // });
    if(!this.loadend) {
      errorLog('Page my be loading. Click again in few seconds...');
      return;
    }


    await imagesLocalStorage.get(data => {
      if(Array.isArray(data)){
        data.forEach((item) =>{
          this.images.push(item.src);
          this.imagesTimes.push(item.time);
        })
      }
    });
    DEBUG ? console.log(this.images) : "";

    console.log( fileuploader.getFiles());
    return;

    this.hirarky  = hierarchy.getJson();
    if(this.hirarky == false){
      errorLog('Invalid Hierarchy. Every node must be child of another node and No sibling nodes are allowed.');
      return;
    }
    DEBUG ? console.log(JSON.stringify(this.hirarky)) : "";

    await screenRecorder.getStatus().then(running => {
      if (running) {
        errorLog('Stop screen recording first...');
        return;
      }
      else if (elementRecoding.getStatus() == true) {
        errorLog('Stop element recording first...');
        return;
      }

      /**save all the tags as comma separated value*/
      this.tagsInput = jQuery(".tag-text").map(function () {
        return jQuery(this).text();
      }).get().join(',');


      if (this.tagsInput == '') {
        errorLog('Put atleast one tag...');
        return;
      }

      if (this.descControl.val() == '') {
        errorLog('Please provide some description...');
        return;
      }

      /**
       * commented to test default
       */
      // this.screenshot = screenshot.getScreenshot();
      // if (this.screenshot == null) {
      //   errorLog('Please paste image...');
      //   return;
      // }



      this.submitBtn.prop('disabled', true);
      // this.submitBtn.disabled = true;

      //working on timer
      this.Timer.timer.pause();
      successLog('storing tags...');

      tagsStoragePrev.set(this.tagsInput, () => {
        // successLog('tags stored...');
      });

      successLog('Removing tags...');
      tagsStorage.set("", () => {
        // successLog('tags removed...');
      });


      successLog('storing nodes...');
      nodesStoragePrev.set(this.hirarky, () => {
        // successLog('tags stored...');
      });
      successLog('Removing nodes...');
      nodesStorage.set("", () => {
        // successLog('tags removed...');
      });



      successLog('Removing description...');
      descStorage.set("", () => {
        // successLog('Description removed...');
      });

      
      successLog('Removing other images');
      imagesLocalStorage.clear( () => {
          //no success callback
       },
      (error) => {
          errorLog(error);
      });

      successLog('converting to plain text...');
      this.sendMessage('GET_TEXT_VERSION');

      return;

    });
  },

  sendMessage: function (msg) {
  
    chrome.tabs.getSelected(null, function (tab) {
      chrome.tabs.sendMessage(tab.id, {
        "msg": msg
      });
    });
  }
}
popup.init();
