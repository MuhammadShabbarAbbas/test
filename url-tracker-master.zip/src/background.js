'use strict';

// With background scripts you can communicate with popup
// and contentScript files.
// For more information on background script,
// See https://developer.chrome.com/extensions/background_pages


// Called when the user clicks on the browser action.


chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  /**
   * return empty response
   */
  // console.log();
  if(jQuery.isEmptyObject(request)){
    sendResponse({
    });
    return true;
  }
});

var screenRecorder = require('./recorders/screen-recorder/screen-recorder.background');
screenRecorder.Recorder.init();

// var ocr = require('./OCR/ocr.background.js'); //this one uses tessaract js
var ocr = require('./OCR/ocr.space.background.js');  //this one uses ocr space
ocr.ocr.init();