export var ocr = {
    init: function () {
        this.bindEvents();
    },
    bindEvents: function () {
        chrome.runtime.onMessage.addListener( function(request, sender, sendResponse){
            if (request.type === 'OCR') {
                this.doOCR(request.payload.url).then((response) => {
                    sendResponse({
                        success: true,
                        payload: response
                    });
                }).catch(error => {
                    sendResponse({
                        success: false,
                        payload: error
                    });
                });
                return true;
            }

        }.bind(this));
    },
    
    doOCR(url) {
        return new Promise(function (resolve, reject) {
            const { createWorker, createScheduler } = require('tesseract.js');

            const scheduler = createScheduler();
            const worker1 = createWorker();
            const worker2 = createWorker();
            const worker3 = createWorker();
            const worker4 = createWorker();



            (async () => {
                await worker1.load();
                await worker2.load();
                await worker3.load();
                await worker4.load();

                await worker1.loadLanguage('eng');
                await worker2.loadLanguage('eng');
                await worker3.loadLanguage('eng');
                await worker4.loadLanguage('eng');


                await worker1.initialize('eng');
                await worker2.initialize('eng');
                await worker3.initialize('eng');
                await worker4.initialize('eng');

                scheduler.addWorker(worker1);
                scheduler.addWorker(worker2);
                scheduler.addWorker(worker3);
                scheduler.addWorker(worker4);
                /** Add 10 recognition jobs */
                // const results = await Promise.all(Array(1).fill(0).map(() => (
                //   scheduler.addJob('recognize', 'https://tesseract.projectnaptha.com/img/eng_bw.png') //url
                // )))
                const results = await Promise.all(Array(1).fill(0).map(() => (
                    scheduler.addJob('recognize', url)
                )))
                DEBUG ? console.log(results) : "";
                resolve(results[0].data.text);
                await scheduler.terminate(); // It also terminates all workers.
            })();

            //working 
            // var base64Str = url;
            // var d = new Date();

            // Tesseract
            // .recognize(base64Str)
            // .then((tesseractResult) => {
            // var t = new Date();
            // console.log("Tesssaract: millis", (t.getTime() - d.getTime()));
            // console.log(tesseractResult);
            // // return tesseractResult;
            // }).catch(err => console.error('tessaract error ', err))
            // .finally(resultOrError => console.log(resultOrError));

            // console.log(url);
            // let base64 = url.split(',')[1];
            // console.log(base64);
            // let imageBuffer = Buffer.from(url, "base64");
            // const { createWorker } = require('tesseract.js');
            // const worker = createWorker();
            // (async () => {
            //   await worker.load();
            //   await worker.loadLanguage('eng');
            //   await worker.initialize('eng');
            //   const { data: { text } } = await worker.recognize(imageBuffer);
            //   await worker.terminate();
            //   resolve(text);
            // })();
        });
    }
}
