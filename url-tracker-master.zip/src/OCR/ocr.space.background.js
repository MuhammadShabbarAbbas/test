export var ocr = {
    init: function () {
        this.bindEvents();
    },
    bindEvents: function () {
        chrome.runtime.onMessage.addListener( function(request, sender, sendResponse){
            if (request.type === 'OCR') {
                this.doOCR(request.payload.url).then((response) => {
                    //return valid response
                    if(typeof(response) == 'object' && 'ParsedResults' in response) {
                        response.ParsedResults.forEach((result) => {
                            if(result.ParsedText)
                            DEBUG ? console.log(result.ParsedText) : "";
                            if ('ParsedText' in result){
                                sendResponse({
                                    success: true,
                                    payload: result.ParsedText
                                });
                            }
                        });
                    }
                    //if parse if not successful for any reason
                    if(typeof(response))
                        sendResponse({
                            success: false,
                            payload:  JSON.stringify(response)
                        });
                    //if response is not an object but a text
                    sendResponse({
                        success: false,
                        payload:  response
                    });

                }).catch(error => {
                    sendResponse({
                        success: false,
                        payload: error
                    });
                });
                return true;
            }

        }.bind(this));
    },
    
    doOCR(url) {
        var data = new FormData();

        data.append("base64Image",url);

        // let data = {
        //     'base64Image' : url
        // };
            var request = {
                method: 'POST',
                data: data,
                withCredentials: true,
                headers: [
                    {
                        key: "apikey",
                        value: OCR_SPACE_API_KEY
                    }
                ],
                url: OCR_SPACE_API_URL
            };
            return PromiseToSendXhr(request);
    }
}
