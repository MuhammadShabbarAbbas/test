export var timer = {
    easytimer : require('easytimer.js'),
    timer : null,
    
    init: function() {
        this.timer = new this.easytimer.Timer();
        this.timer.start();
        this.bindEvents();
    },

    bindEvents : function(){
        chrome.runtime.onMessage.addListener(function (request, sender, callback) {
            switch (request.msg) {
                case "GET_ELAPSED_TIME":
                    DEBUG ? console.log('timer request received; current time is :' + this.time()) : "";
                    chrome.extension.sendMessage({
                        "msg": "ELAPSED_TIME",
                        "value" : this.time()
                    });
                    break;
                case "RESET_ELAPSED_TIME":
                    this.init();
                    break;
            }
        }.bind(this));
    },

    time : function(){
        return this.timer.getTimeValues();
    }
}

