export var timer = {
   
    timer: null,

    /**
     * 
     * @param {Optional start time. If null, timer will be started from 0} startTime 
     */
    init: function () {
      
        this.start();
        this.bindEvents();

        /**send message to get elapsed time**/
        chrome.tabs.getSelected(null,  (tab) => {
            chrome.tabs.sendMessage(tab.id, {
                "msg": "GET_ELAPSED_TIME"
            });
        });

    },
    
    bindEvents: function () {
        chrome.runtime.onMessage.addListener(function (request, sender, callback) {
            switch (request.msg) {
                //get elapsed time and start timer as per returned value from content script
                case "ELAPSED_TIME":
                    this.start(request.value);
                    break;
            }
        }.bind(this));
    },

    start(startTime){
        var easytimer =  require('easytimer.js');
        this.timer = new easytimer.Timer();
        this.timer.start({ precision: 'seconds', startValues: startTime });
        this.timer.addEventListener("secondsUpdated",  (e) => {
            $("#timer").html(this.timer.getTimeValues().toString());
        });
    },


    time : function(){
        return this.timer.getTimeValues().toString();
    },

    pause : function(){
        return this.timer.pause();
    },

    reset: function () {
        this.timer.reset();
        // this.timer = new easytimer.Timer();
        // // timer.start();
        // this.timer.start();
        // this.Timer.addEventListener("secondsUpdated", function (e) {
        //     $("#timer").html(this.tim.getTimeValues().toString());
        // });

        /**reset page's timer after submit 
         * This is handle time of ajax pages
        */
        chrome.tabs.getSelected(null, (tab) => {
            chrome.tabs.sendMessage(tab.id, {
                "msg": "RESET_ELAPSED_TIME"
            });
        });
    }

}
