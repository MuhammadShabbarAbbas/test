export var Recorder = {
  recordRTC: null,
  recordRTCA: null,
  stream: null,

  winID : null,

  startTime : null,
  stopTime : null,

  init: function () {
    this.bindEvents();
  },
  bindEvents: function () {
    /**
     * @since 1.3.5
     * Added to get status of tab recording to auto start heartbeat if page was refresh.
     */
    chrome.runtime.onMessage.addListener( function(request, sender, sendResponse){
      if (request.type === 'TABRECORDER.STATUS') {
        chrome.tabs.getSelected(null, (tab) => {
          chrome.tabCapture.getCapturedTabs(
              function (tabs) {
                tabs.forEach((item, index) => {
                  if (item.tabId == tab.id && item.status == "active") {
                    sendResponse({
                      status : true,
                    });
                  }
                });
                sendResponse({
                  status : false,
                });
              });
        });

        return true;
      }
    }.bind(this));

    /**
     * @since 1.3.4
     * Commented as heartbeat logic implemented
     */
    // chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    //   switch (request.msg) {
    //     case "SET_WIN_ID":
    //
    //     /**
    //      * close win id in 3 seconds
    //      */
    //     /**
    //      * If it works, remove window removing functions.
    //      * Screenshot may also work with scroll if we show a window
    //      */
    //       // setTimeout(function () {
    //       //       chrome.windows.remove(request.value);
    //       //   }, 3000);
    //
    //       this.winID = request.value;
    //       break;
    //     case "GET_WIN_ID":
    //       chrome.extension.sendMessage({
    //         "msg": "WIN_ID",
    //         "value": this.winID,
    //       });
    //       /**
    //        * Empty win id after sending once.
    //        */
    //       this.winID = null;
    //       break;
    //   }
    // }.bind(this));

    // on the listening side
    chrome.runtime.onConnect.addListener(function (port) {
      port.onMessage.addListener((message) => {
        switch (message.acknowledgment) {
          case "CAPTURE_TAB":
            this.tabCapture().then(() => {
              port.postMessage({
                acknowledgment: message.acknowledgment,
                data: true
              });
            }).catch(err => {
              
              port.postMessage({
                acknowledgment: message.acknowledgment,
                data: false
              });
            });

            break;
          case "STOP_CAPTURE":
            this.stopCapture().then(capture => {
              port.postMessage({
                acknowledgment: message.acknowledgment,
                data: capture
              });
            });
            /**
             * Catch creates problem here 
             */
            // .catch( err =>{
            //   port.postMessage({
            //     acknowledgment: message.acknowledgment,
            //     data: err
            //   });
            // });
            break;
        }
      });
    }.bind(this));
  },

  tabCapture: function () {
    return new Promise(function (resolve, reject) {
      chrome.tabs.getSelected(null, (tab) => {
        var video_constraints = {
          mandatory: {
            chromeMediaSource: 'tab'
          }
        };
        var constraints = {
          audio: true,
          video: true,
          videoConstraints: video_constraints
        };
        try {
          chrome.tabCapture.capture(constraints,  (stream) => {
            if (!stream) {
              reject("An error occured in tab capture...");
            }
            this.stream = stream;

            var RecordRTC = require('RecordRTC');

            var context = new AudioContext();
            context.createMediaStreamSource(this.stream).connect(context.destination);

            var options = {
              type: 'video',
              mimeType: 'video/webm',
              // minimum time between pushing frames to Whammy (in milliseconds)
              frameInterval: 50,
              video: {
                width: 1280,
                height: 720
              },
              canvas: {
                width: 1280,
                height: 720
              }
            };
            var optionsA = {
              type: 'audio',
              mimeType: 'audio/webm',
            };
            this.recordRTCA = new RecordRTC(this.stream, optionsA);
            this.recordRTCA.startRecording();

            this.recordRTC = new RecordRTC(this.stream, options);
            this.recordRTC.startRecording();

            this.startTime = Math.round((new Date()).getTime() / 1000);
            resolve();
          });
        }
        catch (err) {
          DEBUG ? console.log("error in tab capture") : "";
          reject(err);
        }
      });
    }.bind(this));
  },

  stopCapture: function () {
    return new Promise( (resolve, reject) => {
      // if (recordRTC == null || recordRTCA == null) {
      //   if (stream != null) {
      //     stream.getAudioTracks().forEach(function (track) {
      //       track.stop();
      //     });
      //     stream.getVideoTracks().forEach(function (track) {
      //       track.stop();
      //     });
      //   }
      //   reject("Recording was not started...");
      // }
      this.stopTime = Math.round((new Date()).getTime() / 1000);

      this.recordRTC.stopRecording((videoURL) => {
        // stream.getVideoTracks()[0].stop();
        this.recordRTC.destroy();
        this.stream.getAudioTracks().forEach((track) => {
          track.stop();
        });
        this.stream.getVideoTracks().forEach((track) => {
          track.stop();
        });

        this.recordRTCA.stopRecording((audioURL) => {
          this.recordRTCA.destroy();
          // stream = null;
          // recordRTC = null;
          // this.recordRTCA = null;

          resolve([audioURL, videoURL, this.startTime, this.stopTime]);
        });
      });
    });
  }
}