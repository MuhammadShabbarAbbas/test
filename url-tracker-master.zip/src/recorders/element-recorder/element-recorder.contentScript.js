
import unique from 'unique-selector';
export var Recorder = {

  status: false,

  inspector: null,

  preview: null,

  recording: null,

  context : null,

  waitForPressResolve: null,

  recordRTC : null,

  startTime : null,

  stopTime : null,

  init: function () {
    this.bindEvents();
  },
  bindEvents: function () {
    chrome.runtime.onMessage.addListener(function (request, sender, callback) {
      switch (request.msg) {
        case "ACTIVATE_INSPECTOR":
          this.activateInspector();
          break;
        case "IS_ELEMENT_RECORDING":
          chrome.extension.sendMessage({
            "msg": "ELEMENT_RECORDING_STATUS",
            "value": this.getStatus(),
          });
          break;
        case "STOP_ELEMENT_RECORDING":
          this.stop();
          /**
           * stop may be called without actual element recording being start
           */
          this.destroyInspector();
          break;
      }
    }.bind(this));


    document.onkeydown = function (evt) {
      evt = evt || window.event;
      var isEscape = false;
      if ("key" in evt) {
        isEscape = (evt.key === "Escape" || evt.key === "Esc");
      } else {
        isEscape = (evt.keyCode === 27);
      }
      if (isEscape) {
        this.destroyInspector();
      }
    }.bind(this);

  },
  /**Dom inspector functions**/
  activateInspector: function() {
    log.success("<ul>" +
      "<li>Select video element in window to record.</li>" +
      "<li>Click outside of video element if click on video does not work</li>" +
      "<li>Press ESC to quit</li>" +
      "<li>Video element must be UNMUTE</li>" +
      "</ul>");
    var DomInspector = require('dom-inspector');
    this.inspector = new DomInspector({ theme: 'url-tracker-inspector-theme' });
    this.inspector.enable();
    setTimeout( 
      ()=>{
        this.context = this.mouseClickListener.bind(this);
        document.addEventListener("click", this.context)  //insert timeout so that no video element log does not show immediately
      }, 500);
      
    this.status = true;
  },

  destroyInspector: function() {
    if (this.inspector != null) {
      this.inspector.disable();
      this.inspector.destroy();
      this.inspector = null;
      log.success("Inspector destroyed...");
      this.status = false;
    }
    document.removeEventListener('click', this.context);
  },


  mouseClickListener: function (event) {
    var uniquePath = unique(this.inspector.target);
    this.recording = document.querySelector(uniquePath);

    this.recording.onended = () => {
      this.stop();
    };

    //append video with unique path if selected is a parent
    if (this.recording == null || this.recording.nodeName != "VIDEO") {
      var uniquePath_video = uniquePath + " video";
      this.recording = document.querySelector(uniquePath_video);
      // check if video element is one of the child of that element. 
      if (this.recording == null || this.recording.nodeName != "VIDEO") {
        /**If video is still not found, check if video is in an iframe**/
        var iframe = document.querySelector(uniquePath + " iframe");
        if (iframe != null && iframe != 'undefined' && iframe.nodeName == 'IFRAME') {
          log.error("Iframe detected. Do screen recording please. Press ESC to quit inspector...");
          return;
        }
        else {
          log.error("video element not found. Try another element. Press ESC to quit inspector...");
          return;
        }
      }
    }

    this.destroyInspector();
    this.createPreview();

    /**Start element recording**/
    
    this.captureStream().then(() => this.startRecording(this.preview.captureStream(), screen))
      .then(recordedChunks => {

        let recordedBlob = new Blob(recordedChunks, { type: "video/webm" });
        this.preview.srcObject = null;
        var vid_url = URL.createObjectURL(recordedBlob);

        // preview.src = vid_url;
        // preview.setAttribute("controls", "controls");
        this.destroyPreview();


        this.status = false;
        /**remove on before unload*/
        // removeEventListener("beforeunload", beforeUnloadListener, { capture: true });
        log.success("Successfully recorded " + recordedBlob.size + " bytes of " +
          recordedBlob.type + " media.");

        this.recordRTC.stopRecording((audioURL) => {
        this.recordRTC.destroy();

        DEBUG ? console.log(audioURL) : "";
        DEBUG ? console.log(vid_url) : "";

        /**
         * as element recording is taking place directly in content script
         * so we are setting it directly without the message being called from pop up
         * Because, when recording stops automatically on video end, pop up is not open and element_recording_url is 
         * useless in this case.
         * but also we send message to pop up, this will be useful when the script is beign stopped from pop up
         */
        recorderHelper.capture =  [audioURL, vid_url, this.startTime, this.stopTime];

          chrome.extension.sendMessage({
            "msg": "ELEMENT_RECORDING",
            "value": [audioURL, vid_url],
          });
          // stream = null;
          // recordRTC = null;
          // this.recordRTCA = null;
        });
        
      })
      .catch(err => {
        log.error(err);
      });
  },


  captureStream: function () {
    var stream = this.recording.captureStream();
    this.preview.srcObject = stream;
    this.preview.captureStream = this.preview.captureStream || this.preview.mozCaptureStream;
    return new Promise(resolve => this.preview.onplaying = resolve);
  },

  createPreview: function () {
    this.preview = document.createElement("video");
    this.preview.setAttribute("autoplay", "autoplay");
    this.preview.muted = true;
    this.preview.setAttribute("id", "url_tracker_preview");
    document.body.appendChild(this.preview);
  },


  /**Media recording functions**/

  startRecording: function (stream) {

    this.startTime = Math.round((new Date()).getTime() / 1000);

    log.success("element recording started....");
    this.status = true;

    let recorder = new MediaRecorder(stream);
    let data = [];

    /**
     * Record Audio
     */
    var options = {
      type: 'audio',
      mimeType: 'audio/webm',
    };
    var RecordRTC = require('RecordRTC');
    this.recordRTC = new RecordRTC(stream, options);
    this.recordRTC.startRecording();

    recorder.ondataavailable = event => data.push(event.data);
    recorder.start();

    //prevent page load while recording is on
    // addEventListener("beforeunload", beforeUnloadListener, { capture: true });

    let stopped = new Promise((resolve, reject) => {
      recorder.onstop = resolve;
      recorder.onerror = event => reject(event.name);
    });


    let recorded = this.wait().then(
      () => recorder.state == "recording" && recorder.stop()
    );

    return Promise.all([
      stopped,
      recorded
    ]).then(() => data);

  },

  destroyPreview: function () {
    document.body.removeChild(this.preview);
  },


  /**Promise to wait until stop recording is pressed**/
  wait: function () {
    // return new Promise(resolve => setTimeout(resolve, delayInMS));
    return new Promise(resolve => this.waitForPressResolve = resolve);
  },

  stop: function () {
    this.stopTime = Math.round((new Date()).getTime() / 1000);

    if (this.waitForPressResolve) this.waitForPressResolve();
    // stream.getTracks().forEach(track => track.stop());
  },

  getStatus: function () {
    return this.status;
  }
}
// elementRecorder.init();