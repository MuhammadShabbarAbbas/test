'use strict';

/**
 * To start action on page loaded completely
 */

chrome.extension.sendMessage({}, function (response) {
  var readyStateCheckInterval = setInterval(function () {
    if (document.readyState === "complete") {
      clearInterval(readyStateCheckInterval);
      initContentScript();
    }
  }, 10);
});

function initContentScript() {
  /**
   * Contrary to other files, below files are initialized via content script because
   * These files use node modules and are used as node script. 
   */

  var elementRecorder = require('./recorders/element-recorder/element-recorder.contentScript');
  elementRecorder.Recorder.init();

  var easyTimer = require('./timer/timer.contentScript');
  easyTimer.timer.init();

  var textVersion = require('./textversion/text-version.contentScript');
  textVersion.textVersion.init();
}


/***********On Before load actions**********/
/**Not using this for now**/
function RegisterOnBeforeUnloadActions() {
  RegisterOnBeforeUnloadFor("#url_tracker_tags_tag", "input");
  RegisterOnBeforeUnloadFor("#url_tracker_desc_input", "input");

  function RegisterOnBeforeUnloadFor(input, action) {
    const nameInput = document.querySelector(input);
    nameInput.addEventListener(action, (event) => {
      if (event.target.value !== "") {
        addEventListener("beforeunload", beforeUnloadListener, { capture: true });
      } else {
        removeEventListener("beforeunload", beforeUnloadListener, { capture: true });
      }
    });
  }
}


const beforeUnloadListener = (event) => {
  event.preventDefault();
  return event.returnValue = "Are you sure you want to exit?";
};

/********END****************/
