export var textVersion = {
	init : function(){
		this.bindEvents();
	}, 
	bindEvents : function(){
		chrome.runtime.onMessage.addListener(function (request, sender, callback) {
			switch(request.msg){
				case "GET_TEXT_VERSION":	
					var textVersion = require("textversionjs");
					var htmlText = jQuery('body').html();
					var plainText = textVersion(htmlText);
					chrome.extension.sendMessage({
						"msg": "TEXT_VERSION",
						"value": plainText,
					});
					break;
			}
		}.bind(this));
	}
}
